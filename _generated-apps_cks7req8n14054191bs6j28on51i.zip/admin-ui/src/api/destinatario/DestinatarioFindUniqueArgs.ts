import { DestinatarioWhereUniqueInput } from "./DestinatarioWhereUniqueInput";

export type DestinatarioFindUniqueArgs = {
  where: DestinatarioWhereUniqueInput;
};
