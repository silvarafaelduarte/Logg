export type DestinatarioWhereUniqueInput = {
  id: string;
};
