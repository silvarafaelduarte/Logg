export type DestinatarioUpdateInput = {
  bairro?: string | null;
  complemento?: string | null;
  logradouro?: string | null;
  nome?: string;
  numero?: string | null;
};
