import { DestinatarioWhereUniqueInput } from "./DestinatarioWhereUniqueInput";

export type DeleteDestinatarioArgs = {
  where: DestinatarioWhereUniqueInput;
};
