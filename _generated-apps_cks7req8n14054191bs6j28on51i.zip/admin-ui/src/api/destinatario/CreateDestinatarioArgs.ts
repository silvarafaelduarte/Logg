import { DestinatarioCreateInput } from "./DestinatarioCreateInput";

export type CreateDestinatarioArgs = {
  data: DestinatarioCreateInput;
};
