import { StatusEntregaCreateInput } from "./StatusEntregaCreateInput";

export type CreateStatusEntregaArgs = {
  data: StatusEntregaCreateInput;
};
