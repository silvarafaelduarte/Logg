import { StatusEntregaWhereUniqueInput } from "./StatusEntregaWhereUniqueInput";

export type StatusEntregaFindUniqueArgs = {
  where: StatusEntregaWhereUniqueInput;
};
