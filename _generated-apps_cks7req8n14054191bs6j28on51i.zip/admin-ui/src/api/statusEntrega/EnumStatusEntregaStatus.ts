export enum EnumStatusEntregaStatus {
  Pendente = "P",
  Finalizada = "F",
  Cancelada = "C",
}
