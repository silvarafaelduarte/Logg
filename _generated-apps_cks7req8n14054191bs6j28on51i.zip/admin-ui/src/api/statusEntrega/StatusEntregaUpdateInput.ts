export type StatusEntregaUpdateInput = {
  status?: "P" | "F" | "C" | null;
};
