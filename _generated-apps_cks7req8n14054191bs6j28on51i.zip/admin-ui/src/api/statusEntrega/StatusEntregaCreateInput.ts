export type StatusEntregaCreateInput = {
  status?: "P" | "F" | "C" | null;
};
