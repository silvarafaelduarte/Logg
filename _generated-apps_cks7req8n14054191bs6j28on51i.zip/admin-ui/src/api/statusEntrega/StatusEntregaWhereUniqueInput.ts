export type StatusEntregaWhereUniqueInput = {
  id: string;
};
