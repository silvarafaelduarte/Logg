import { StatusEntregaWhereUniqueInput } from "./StatusEntregaWhereUniqueInput";

export type DeleteStatusEntregaArgs = {
  where: StatusEntregaWhereUniqueInput;
};
