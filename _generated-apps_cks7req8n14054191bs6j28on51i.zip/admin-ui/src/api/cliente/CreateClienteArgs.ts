import { ClienteCreateInput } from "./ClienteCreateInput";

export type CreateClienteArgs = {
  data: ClienteCreateInput;
};
