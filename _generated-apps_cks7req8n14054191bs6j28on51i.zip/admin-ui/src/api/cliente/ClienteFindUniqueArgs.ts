import { ClienteWhereUniqueInput } from "./ClienteWhereUniqueInput";

export type ClienteFindUniqueArgs = {
  where: ClienteWhereUniqueInput;
};
