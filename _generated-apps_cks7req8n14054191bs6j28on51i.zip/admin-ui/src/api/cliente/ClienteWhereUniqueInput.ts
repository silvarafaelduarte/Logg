export type ClienteWhereUniqueInput = {
  id: string;
};
