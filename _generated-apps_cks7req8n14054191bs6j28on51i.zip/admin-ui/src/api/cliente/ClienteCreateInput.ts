export type ClienteCreateInput = {
  email?: string | null;
  nome: string;
  telefone?: string | null;
};
