import { ClienteWhereUniqueInput } from "./ClienteWhereUniqueInput";

export type DeleteClienteArgs = {
  where: ClienteWhereUniqueInput;
};
