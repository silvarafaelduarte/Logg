import { UserWhereUniqueInput } from "./UserWhereUniqueInput";

export type UserFindUniqueArgs = {
  where: UserWhereUniqueInput;
};
