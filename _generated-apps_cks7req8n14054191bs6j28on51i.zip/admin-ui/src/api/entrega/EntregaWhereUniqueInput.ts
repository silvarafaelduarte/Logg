export type EntregaWhereUniqueInput = {
  id: string;
};
