import { EntregaCreateInput } from "./EntregaCreateInput";

export type CreateEntregaArgs = {
  data: EntregaCreateInput;
};
