import { EntregaWhereUniqueInput } from "./EntregaWhereUniqueInput";

export type DeleteEntregaArgs = {
  where: EntregaWhereUniqueInput;
};
