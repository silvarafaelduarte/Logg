import { EntregaWhereUniqueInput } from "./EntregaWhereUniqueInput";

export type EntregaFindUniqueArgs = {
  where: EntregaWhereUniqueInput;
};
