export type OcorrenciaUpdateInput = {
  dataRegistro?: Date | null;
  descricao?: string;
};
