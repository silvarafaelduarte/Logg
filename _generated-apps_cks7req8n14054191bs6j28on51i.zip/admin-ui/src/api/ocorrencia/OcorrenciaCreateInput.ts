export type OcorrenciaCreateInput = {
  dataRegistro?: Date | null;
  descricao: string;
};
