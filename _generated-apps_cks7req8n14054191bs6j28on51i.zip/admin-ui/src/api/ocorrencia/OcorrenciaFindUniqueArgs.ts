import { OcorrenciaWhereUniqueInput } from "./OcorrenciaWhereUniqueInput";

export type OcorrenciaFindUniqueArgs = {
  where: OcorrenciaWhereUniqueInput;
};
