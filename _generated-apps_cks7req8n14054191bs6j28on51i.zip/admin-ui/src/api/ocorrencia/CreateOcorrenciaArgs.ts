import { OcorrenciaCreateInput } from "./OcorrenciaCreateInput";

export type CreateOcorrenciaArgs = {
  data: OcorrenciaCreateInput;
};
