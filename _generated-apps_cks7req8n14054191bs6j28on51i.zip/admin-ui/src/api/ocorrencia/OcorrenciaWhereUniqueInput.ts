export type OcorrenciaWhereUniqueInput = {
  id: string;
};
