import { OcorrenciaWhereUniqueInput } from "./OcorrenciaWhereUniqueInput";

export type DeleteOcorrenciaArgs = {
  where: OcorrenciaWhereUniqueInput;
};
