import { ArgsType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import { OcorrenciaWhereInput } from "./OcorrenciaWhereInput";
import { Type } from "class-transformer";
import { OcorrenciaOrderByInput } from "./OcorrenciaOrderByInput";

@ArgsType()
class OcorrenciaFindManyArgs {
  @ApiProperty({
    required: false,
    type: () => OcorrenciaWhereInput,
  })
  @Field(() => OcorrenciaWhereInput, { nullable: true })
  @Type(() => OcorrenciaWhereInput)
  where?: OcorrenciaWhereInput;

  @ApiProperty({
    required: false,
    type: OcorrenciaOrderByInput,
  })
  @Field(() => OcorrenciaOrderByInput, { nullable: true })
  @Type(() => OcorrenciaOrderByInput)
  orderBy?: OcorrenciaOrderByInput;

  @ApiProperty({
    required: false,
    type: Number,
  })
  @Field(() => Number, { nullable: true })
  @Type(() => Number)
  skip?: number;

  @ApiProperty({
    required: false,
    type: Number,
  })
  @Field(() => Number, { nullable: true })
  @Type(() => Number)
  take?: number;
}

export { OcorrenciaFindManyArgs };
