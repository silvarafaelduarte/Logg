import { ArgsType, Field } from "@nestjs/graphql";
import { OcorrenciaCreateInput } from "./OcorrenciaCreateInput";

@ArgsType()
class CreateOcorrenciaArgs {
  @Field(() => OcorrenciaCreateInput, { nullable: false })
  data!: OcorrenciaCreateInput;
}

export { CreateOcorrenciaArgs };
