import { ArgsType, Field } from "@nestjs/graphql";
import { OcorrenciaWhereUniqueInput } from "./OcorrenciaWhereUniqueInput";
import { OcorrenciaUpdateInput } from "./OcorrenciaUpdateInput";

@ArgsType()
class UpdateOcorrenciaArgs {
  @Field(() => OcorrenciaWhereUniqueInput, { nullable: false })
  where!: OcorrenciaWhereUniqueInput;
  @Field(() => OcorrenciaUpdateInput, { nullable: false })
  data!: OcorrenciaUpdateInput;
}

export { UpdateOcorrenciaArgs };
