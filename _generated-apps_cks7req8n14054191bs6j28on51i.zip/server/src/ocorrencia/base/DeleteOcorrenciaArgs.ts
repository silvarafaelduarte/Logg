import { ArgsType, Field } from "@nestjs/graphql";
import { OcorrenciaWhereUniqueInput } from "./OcorrenciaWhereUniqueInput";

@ArgsType()
class DeleteOcorrenciaArgs {
  @Field(() => OcorrenciaWhereUniqueInput, { nullable: false })
  where!: OcorrenciaWhereUniqueInput;
}

export { DeleteOcorrenciaArgs };
