import { PrismaService } from "nestjs-prisma";
import { Prisma, Ocorrencia, Entrega } from "@prisma/client";

export class OcorrenciaServiceBase {
  constructor(protected readonly prisma: PrismaService) {}

  async count<T extends Prisma.OcorrenciaFindManyArgs>(
    args: Prisma.SelectSubset<T, Prisma.OcorrenciaFindManyArgs>
  ): Promise<number> {
    return this.prisma.ocorrencia.count(args);
  }

  async findMany<T extends Prisma.OcorrenciaFindManyArgs>(
    args: Prisma.SelectSubset<T, Prisma.OcorrenciaFindManyArgs>
  ): Promise<Ocorrencia[]> {
    return this.prisma.ocorrencia.findMany(args);
  }
  async findOne<T extends Prisma.OcorrenciaFindUniqueArgs>(
    args: Prisma.SelectSubset<T, Prisma.OcorrenciaFindUniqueArgs>
  ): Promise<Ocorrencia | null> {
    return this.prisma.ocorrencia.findUnique(args);
  }
  async create<T extends Prisma.OcorrenciaCreateArgs>(
    args: Prisma.SelectSubset<T, Prisma.OcorrenciaCreateArgs>
  ): Promise<Ocorrencia> {
    return this.prisma.ocorrencia.create<T>(args);
  }
  async update<T extends Prisma.OcorrenciaUpdateArgs>(
    args: Prisma.SelectSubset<T, Prisma.OcorrenciaUpdateArgs>
  ): Promise<Ocorrencia> {
    return this.prisma.ocorrencia.update<T>(args);
  }
  async delete<T extends Prisma.OcorrenciaDeleteArgs>(
    args: Prisma.SelectSubset<T, Prisma.OcorrenciaDeleteArgs>
  ): Promise<Ocorrencia> {
    return this.prisma.ocorrencia.delete(args);
  }

  async findEntregas(
    parentId: string,
    args: Prisma.EntregaFindManyArgs
  ): Promise<Entrega[]> {
    return this.prisma.ocorrencia
      .findUnique({
        where: { id: parentId },
      })
      .entregas(args);
  }
}
