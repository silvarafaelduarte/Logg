import { ArgsType, Field } from "@nestjs/graphql";
import { OcorrenciaWhereUniqueInput } from "./OcorrenciaWhereUniqueInput";

@ArgsType()
class OcorrenciaFindUniqueArgs {
  @Field(() => OcorrenciaWhereUniqueInput, { nullable: false })
  where!: OcorrenciaWhereUniqueInput;
}

export { OcorrenciaFindUniqueArgs };
