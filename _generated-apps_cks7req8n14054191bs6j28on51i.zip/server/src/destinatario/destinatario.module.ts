import { Module } from "@nestjs/common";
import { DestinatarioModuleBase } from "./base/destinatario.module.base";
import { DestinatarioService } from "./destinatario.service";
import { DestinatarioController } from "./destinatario.controller";
import { DestinatarioResolver } from "./destinatario.resolver";

@Module({
  imports: [DestinatarioModuleBase],
  controllers: [DestinatarioController],
  providers: [DestinatarioService, DestinatarioResolver],
  exports: [DestinatarioService],
})
export class DestinatarioModule {}
