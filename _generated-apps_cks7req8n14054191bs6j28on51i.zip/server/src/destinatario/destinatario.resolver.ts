import * as common from "@nestjs/common";
import * as graphql from "@nestjs/graphql";
import * as nestAccessControl from "nest-access-control";
import * as gqlDefaultAuthGuard from "../auth/gqlDefaultAuth.guard";
import * as gqlACGuard from "../auth/gqlAC.guard";
import { DestinatarioResolverBase } from "./base/destinatario.resolver.base";
import { Destinatario } from "./base/Destinatario";
import { DestinatarioService } from "./destinatario.service";

@graphql.Resolver(() => Destinatario)
@common.UseGuards(
  gqlDefaultAuthGuard.GqlDefaultAuthGuard,
  gqlACGuard.GqlACGuard
)
export class DestinatarioResolver extends DestinatarioResolverBase {
  constructor(
    protected readonly service: DestinatarioService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
