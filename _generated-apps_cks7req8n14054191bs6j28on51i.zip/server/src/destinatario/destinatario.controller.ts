import * as common from "@nestjs/common";
import * as swagger from "@nestjs/swagger";
import * as nestAccessControl from "nest-access-control";
import { DestinatarioService } from "./destinatario.service";
import { DestinatarioControllerBase } from "./base/destinatario.controller.base";

@swagger.ApiBasicAuth()
@swagger.ApiTags("destinatarios")
@common.Controller("destinatarios")
export class DestinatarioController extends DestinatarioControllerBase {
  constructor(
    protected readonly service: DestinatarioService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
