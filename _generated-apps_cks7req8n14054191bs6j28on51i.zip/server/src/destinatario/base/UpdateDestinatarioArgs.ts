import { ArgsType, Field } from "@nestjs/graphql";
import { DestinatarioWhereUniqueInput } from "./DestinatarioWhereUniqueInput";
import { DestinatarioUpdateInput } from "./DestinatarioUpdateInput";

@ArgsType()
class UpdateDestinatarioArgs {
  @Field(() => DestinatarioWhereUniqueInput, { nullable: false })
  where!: DestinatarioWhereUniqueInput;
  @Field(() => DestinatarioUpdateInput, { nullable: false })
  data!: DestinatarioUpdateInput;
}

export { UpdateDestinatarioArgs };
