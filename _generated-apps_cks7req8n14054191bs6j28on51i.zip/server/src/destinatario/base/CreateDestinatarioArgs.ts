import { ArgsType, Field } from "@nestjs/graphql";
import { DestinatarioCreateInput } from "./DestinatarioCreateInput";

@ArgsType()
class CreateDestinatarioArgs {
  @Field(() => DestinatarioCreateInput, { nullable: false })
  data!: DestinatarioCreateInput;
}

export { CreateDestinatarioArgs };
