import { ArgsType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import { DestinatarioWhereInput } from "./DestinatarioWhereInput";
import { Type } from "class-transformer";
import { DestinatarioOrderByInput } from "./DestinatarioOrderByInput";

@ArgsType()
class DestinatarioFindManyArgs {
  @ApiProperty({
    required: false,
    type: () => DestinatarioWhereInput,
  })
  @Field(() => DestinatarioWhereInput, { nullable: true })
  @Type(() => DestinatarioWhereInput)
  where?: DestinatarioWhereInput;

  @ApiProperty({
    required: false,
    type: DestinatarioOrderByInput,
  })
  @Field(() => DestinatarioOrderByInput, { nullable: true })
  @Type(() => DestinatarioOrderByInput)
  orderBy?: DestinatarioOrderByInput;

  @ApiProperty({
    required: false,
    type: Number,
  })
  @Field(() => Number, { nullable: true })
  @Type(() => Number)
  skip?: number;

  @ApiProperty({
    required: false,
    type: Number,
  })
  @Field(() => Number, { nullable: true })
  @Type(() => Number)
  take?: number;
}

export { DestinatarioFindManyArgs };
