import { PrismaService } from "nestjs-prisma";
import { Prisma, Destinatario, Entrega } from "@prisma/client";

export class DestinatarioServiceBase {
  constructor(protected readonly prisma: PrismaService) {}

  async count<T extends Prisma.DestinatarioFindManyArgs>(
    args: Prisma.SelectSubset<T, Prisma.DestinatarioFindManyArgs>
  ): Promise<number> {
    return this.prisma.destinatario.count(args);
  }

  async findMany<T extends Prisma.DestinatarioFindManyArgs>(
    args: Prisma.SelectSubset<T, Prisma.DestinatarioFindManyArgs>
  ): Promise<Destinatario[]> {
    return this.prisma.destinatario.findMany(args);
  }
  async findOne<T extends Prisma.DestinatarioFindUniqueArgs>(
    args: Prisma.SelectSubset<T, Prisma.DestinatarioFindUniqueArgs>
  ): Promise<Destinatario | null> {
    return this.prisma.destinatario.findUnique(args);
  }
  async create<T extends Prisma.DestinatarioCreateArgs>(
    args: Prisma.SelectSubset<T, Prisma.DestinatarioCreateArgs>
  ): Promise<Destinatario> {
    return this.prisma.destinatario.create<T>(args);
  }
  async update<T extends Prisma.DestinatarioUpdateArgs>(
    args: Prisma.SelectSubset<T, Prisma.DestinatarioUpdateArgs>
  ): Promise<Destinatario> {
    return this.prisma.destinatario.update<T>(args);
  }
  async delete<T extends Prisma.DestinatarioDeleteArgs>(
    args: Prisma.SelectSubset<T, Prisma.DestinatarioDeleteArgs>
  ): Promise<Destinatario> {
    return this.prisma.destinatario.delete(args);
  }

  async findEntregas(
    parentId: string,
    args: Prisma.EntregaFindManyArgs
  ): Promise<Entrega[]> {
    return this.prisma.destinatario
      .findUnique({
        where: { id: parentId },
      })
      .entregas(args);
  }
}
