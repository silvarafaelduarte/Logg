import { ArgsType, Field } from "@nestjs/graphql";
import { DestinatarioWhereUniqueInput } from "./DestinatarioWhereUniqueInput";

@ArgsType()
class DeleteDestinatarioArgs {
  @Field(() => DestinatarioWhereUniqueInput, { nullable: false })
  where!: DestinatarioWhereUniqueInput;
}

export { DeleteDestinatarioArgs };
