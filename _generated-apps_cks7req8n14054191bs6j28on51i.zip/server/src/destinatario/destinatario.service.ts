import { Injectable } from "@nestjs/common";
import { PrismaService } from "nestjs-prisma";
import { DestinatarioServiceBase } from "./base/destinatario.service.base";

@Injectable()
export class DestinatarioService extends DestinatarioServiceBase {
  constructor(protected readonly prisma: PrismaService) {
    super(prisma);
  }
}
