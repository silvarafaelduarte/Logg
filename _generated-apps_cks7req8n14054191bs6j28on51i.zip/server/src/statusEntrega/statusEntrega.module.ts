import { Module } from "@nestjs/common";
import { StatusEntregaModuleBase } from "./base/statusEntrega.module.base";
import { StatusEntregaService } from "./statusEntrega.service";
import { StatusEntregaController } from "./statusEntrega.controller";
import { StatusEntregaResolver } from "./statusEntrega.resolver";

@Module({
  imports: [StatusEntregaModuleBase],
  controllers: [StatusEntregaController],
  providers: [StatusEntregaService, StatusEntregaResolver],
  exports: [StatusEntregaService],
})
export class StatusEntregaModule {}
