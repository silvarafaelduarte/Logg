import { Injectable } from "@nestjs/common";
import { PrismaService } from "nestjs-prisma";
import { StatusEntregaServiceBase } from "./base/statusEntrega.service.base";

@Injectable()
export class StatusEntregaService extends StatusEntregaServiceBase {
  constructor(protected readonly prisma: PrismaService) {
    super(prisma);
  }
}
