import { ArgsType, Field } from "@nestjs/graphql";
import { StatusEntregaWhereUniqueInput } from "./StatusEntregaWhereUniqueInput";

@ArgsType()
class DeleteStatusEntregaArgs {
  @Field(() => StatusEntregaWhereUniqueInput, { nullable: false })
  where!: StatusEntregaWhereUniqueInput;
}

export { DeleteStatusEntregaArgs };
