import { ArgsType, Field } from "@nestjs/graphql";
import { StatusEntregaWhereUniqueInput } from "./StatusEntregaWhereUniqueInput";
import { StatusEntregaUpdateInput } from "./StatusEntregaUpdateInput";

@ArgsType()
class UpdateStatusEntregaArgs {
  @Field(() => StatusEntregaWhereUniqueInput, { nullable: false })
  where!: StatusEntregaWhereUniqueInput;
  @Field(() => StatusEntregaUpdateInput, { nullable: false })
  data!: StatusEntregaUpdateInput;
}

export { UpdateStatusEntregaArgs };
