import { ArgsType, Field } from "@nestjs/graphql";
import { StatusEntregaCreateInput } from "./StatusEntregaCreateInput";

@ArgsType()
class CreateStatusEntregaArgs {
  @Field(() => StatusEntregaCreateInput, { nullable: false })
  data!: StatusEntregaCreateInput;
}

export { CreateStatusEntregaArgs };
