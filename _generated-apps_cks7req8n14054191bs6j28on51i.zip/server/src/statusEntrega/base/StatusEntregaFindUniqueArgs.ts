import { ArgsType, Field } from "@nestjs/graphql";
import { StatusEntregaWhereUniqueInput } from "./StatusEntregaWhereUniqueInput";

@ArgsType()
class StatusEntregaFindUniqueArgs {
  @Field(() => StatusEntregaWhereUniqueInput, { nullable: false })
  where!: StatusEntregaWhereUniqueInput;
}

export { StatusEntregaFindUniqueArgs };
