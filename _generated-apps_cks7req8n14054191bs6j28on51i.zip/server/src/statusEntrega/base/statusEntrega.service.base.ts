import { PrismaService } from "nestjs-prisma";
import { Prisma, StatusEntrega, Entrega } from "@prisma/client";

export class StatusEntregaServiceBase {
  constructor(protected readonly prisma: PrismaService) {}

  async count<T extends Prisma.StatusEntregaFindManyArgs>(
    args: Prisma.SelectSubset<T, Prisma.StatusEntregaFindManyArgs>
  ): Promise<number> {
    return this.prisma.statusEntrega.count(args);
  }

  async findMany<T extends Prisma.StatusEntregaFindManyArgs>(
    args: Prisma.SelectSubset<T, Prisma.StatusEntregaFindManyArgs>
  ): Promise<StatusEntrega[]> {
    return this.prisma.statusEntrega.findMany(args);
  }
  async findOne<T extends Prisma.StatusEntregaFindUniqueArgs>(
    args: Prisma.SelectSubset<T, Prisma.StatusEntregaFindUniqueArgs>
  ): Promise<StatusEntrega | null> {
    return this.prisma.statusEntrega.findUnique(args);
  }
  async create<T extends Prisma.StatusEntregaCreateArgs>(
    args: Prisma.SelectSubset<T, Prisma.StatusEntregaCreateArgs>
  ): Promise<StatusEntrega> {
    return this.prisma.statusEntrega.create<T>(args);
  }
  async update<T extends Prisma.StatusEntregaUpdateArgs>(
    args: Prisma.SelectSubset<T, Prisma.StatusEntregaUpdateArgs>
  ): Promise<StatusEntrega> {
    return this.prisma.statusEntrega.update<T>(args);
  }
  async delete<T extends Prisma.StatusEntregaDeleteArgs>(
    args: Prisma.SelectSubset<T, Prisma.StatusEntregaDeleteArgs>
  ): Promise<StatusEntrega> {
    return this.prisma.statusEntrega.delete(args);
  }

  async findEntregas(
    parentId: string,
    args: Prisma.EntregaFindManyArgs
  ): Promise<Entrega[]> {
    return this.prisma.statusEntrega
      .findUnique({
        where: { id: parentId },
      })
      .entregas(args);
  }
}
