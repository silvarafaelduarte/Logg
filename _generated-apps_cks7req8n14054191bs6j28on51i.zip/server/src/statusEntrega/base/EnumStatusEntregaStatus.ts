import { registerEnumType } from "@nestjs/graphql";

export enum EnumStatusEntregaStatus {
  Pendente = "P",
  Finalizada = "F",
  Cancelada = "C",
}

registerEnumType(EnumStatusEntregaStatus, {
  name: "EnumStatusEntregaStatus",
});
