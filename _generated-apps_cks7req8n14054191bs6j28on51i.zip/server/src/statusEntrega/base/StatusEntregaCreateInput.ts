import { InputType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import { EnumStatusEntregaStatus } from "./EnumStatusEntregaStatus";
import { IsEnum, IsOptional } from "class-validator";
@InputType()
class StatusEntregaCreateInput {
  @ApiProperty({
    required: false,
    enum: EnumStatusEntregaStatus,
  })
  @IsEnum(EnumStatusEntregaStatus)
  @IsOptional()
  @Field(() => EnumStatusEntregaStatus, {
    nullable: true,
  })
  status?: "P" | "F" | "C" | null;
}
export { StatusEntregaCreateInput };
