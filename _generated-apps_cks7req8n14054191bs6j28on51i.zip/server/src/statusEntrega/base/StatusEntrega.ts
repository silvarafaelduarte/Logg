import { ObjectType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import {
  IsDate,
  ValidateNested,
  IsOptional,
  IsString,
  IsEnum,
} from "class-validator";
import { Type } from "class-transformer";
import { Entrega } from "../../entrega/base/Entrega";
import { EnumStatusEntregaStatus } from "./EnumStatusEntregaStatus";
@ObjectType()
class StatusEntrega {
  @ApiProperty({
    required: true,
  })
  @IsDate()
  @Type(() => Date)
  @Field(() => Date)
  createdAt!: Date;

  @ApiProperty({
    required: false,
    type: () => [Entrega],
  })
  @ValidateNested()
  @Type(() => Entrega)
  @IsOptional()
  entregas?: Array<Entrega>;

  @ApiProperty({
    required: true,
    type: String,
  })
  @IsString()
  @Field(() => String)
  id!: string;

  @ApiProperty({
    required: false,
    enum: EnumStatusEntregaStatus,
  })
  @IsEnum(EnumStatusEntregaStatus)
  @IsOptional()
  @Field(() => EnumStatusEntregaStatus, {
    nullable: true,
  })
  status?: "P" | "F" | "C" | null;

  @ApiProperty({
    required: true,
  })
  @IsDate()
  @Type(() => Date)
  @Field(() => Date)
  updatedAt!: Date;
}
export { StatusEntrega };
