import { ArgsType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import { StatusEntregaWhereInput } from "./StatusEntregaWhereInput";
import { Type } from "class-transformer";
import { StatusEntregaOrderByInput } from "./StatusEntregaOrderByInput";

@ArgsType()
class StatusEntregaFindManyArgs {
  @ApiProperty({
    required: false,
    type: () => StatusEntregaWhereInput,
  })
  @Field(() => StatusEntregaWhereInput, { nullable: true })
  @Type(() => StatusEntregaWhereInput)
  where?: StatusEntregaWhereInput;

  @ApiProperty({
    required: false,
    type: StatusEntregaOrderByInput,
  })
  @Field(() => StatusEntregaOrderByInput, { nullable: true })
  @Type(() => StatusEntregaOrderByInput)
  orderBy?: StatusEntregaOrderByInput;

  @ApiProperty({
    required: false,
    type: Number,
  })
  @Field(() => Number, { nullable: true })
  @Type(() => Number)
  skip?: number;

  @ApiProperty({
    required: false,
    type: Number,
  })
  @Field(() => Number, { nullable: true })
  @Type(() => Number)
  take?: number;
}

export { StatusEntregaFindManyArgs };
