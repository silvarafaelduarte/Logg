import { InputType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import { StringFilter } from "../../util/StringFilter";
import { Type } from "class-transformer";
import { IsOptional, IsEnum } from "class-validator";
import { EnumStatusEntregaStatus } from "./EnumStatusEntregaStatus";
@InputType()
class StatusEntregaWhereInput {
  @ApiProperty({
    required: false,
    type: StringFilter,
  })
  @Type(() => StringFilter)
  @IsOptional()
  @Field(() => StringFilter, {
    nullable: true,
  })
  id?: StringFilter;

  @ApiProperty({
    required: false,
    enum: EnumStatusEntregaStatus,
  })
  @IsEnum(EnumStatusEntregaStatus)
  @IsOptional()
  @Field(() => EnumStatusEntregaStatus, {
    nullable: true,
  })
  status?: "P" | "F" | "C";
}
export { StatusEntregaWhereInput };
