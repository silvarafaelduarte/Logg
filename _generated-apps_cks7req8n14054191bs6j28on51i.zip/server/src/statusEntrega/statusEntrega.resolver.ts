import * as common from "@nestjs/common";
import * as graphql from "@nestjs/graphql";
import * as nestAccessControl from "nest-access-control";
import * as gqlDefaultAuthGuard from "../auth/gqlDefaultAuth.guard";
import * as gqlACGuard from "../auth/gqlAC.guard";
import { StatusEntregaResolverBase } from "./base/statusEntrega.resolver.base";
import { StatusEntrega } from "./base/StatusEntrega";
import { StatusEntregaService } from "./statusEntrega.service";

@graphql.Resolver(() => StatusEntrega)
@common.UseGuards(
  gqlDefaultAuthGuard.GqlDefaultAuthGuard,
  gqlACGuard.GqlACGuard
)
export class StatusEntregaResolver extends StatusEntregaResolverBase {
  constructor(
    protected readonly service: StatusEntregaService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
