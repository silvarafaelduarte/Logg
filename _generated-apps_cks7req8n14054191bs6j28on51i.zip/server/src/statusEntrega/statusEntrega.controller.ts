import * as common from "@nestjs/common";
import * as swagger from "@nestjs/swagger";
import * as nestAccessControl from "nest-access-control";
import { StatusEntregaService } from "./statusEntrega.service";
import { StatusEntregaControllerBase } from "./base/statusEntrega.controller.base";

@swagger.ApiBasicAuth()
@swagger.ApiTags("status-entregas")
@common.Controller("status-entregas")
export class StatusEntregaController extends StatusEntregaControllerBase {
  constructor(
    protected readonly service: StatusEntregaService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
