import { BasicAuthGuard } from "./basicAuth.guard";

export class DefaultAuthGuard extends BasicAuthGuard {}
