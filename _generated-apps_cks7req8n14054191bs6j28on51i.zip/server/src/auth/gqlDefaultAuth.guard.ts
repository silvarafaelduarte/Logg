import { GqlBasicAuthGuard } from "./gqlBasicAuth.guard";

export class GqlDefaultAuthGuard extends GqlBasicAuthGuard {}
