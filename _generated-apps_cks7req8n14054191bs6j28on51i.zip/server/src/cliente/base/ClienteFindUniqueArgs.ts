import { ArgsType, Field } from "@nestjs/graphql";
import { ClienteWhereUniqueInput } from "./ClienteWhereUniqueInput";

@ArgsType()
class ClienteFindUniqueArgs {
  @Field(() => ClienteWhereUniqueInput, { nullable: false })
  where!: ClienteWhereUniqueInput;
}

export { ClienteFindUniqueArgs };
