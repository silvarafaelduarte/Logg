import { ArgsType, Field } from "@nestjs/graphql";
import { ClienteWhereUniqueInput } from "./ClienteWhereUniqueInput";
import { ClienteUpdateInput } from "./ClienteUpdateInput";

@ArgsType()
class UpdateClienteArgs {
  @Field(() => ClienteWhereUniqueInput, { nullable: false })
  where!: ClienteWhereUniqueInput;
  @Field(() => ClienteUpdateInput, { nullable: false })
  data!: ClienteUpdateInput;
}

export { UpdateClienteArgs };
