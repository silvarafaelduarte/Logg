import { ArgsType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import { ClienteWhereInput } from "./ClienteWhereInput";
import { Type } from "class-transformer";
import { ClienteOrderByInput } from "./ClienteOrderByInput";

@ArgsType()
class ClienteFindManyArgs {
  @ApiProperty({
    required: false,
    type: () => ClienteWhereInput,
  })
  @Field(() => ClienteWhereInput, { nullable: true })
  @Type(() => ClienteWhereInput)
  where?: ClienteWhereInput;

  @ApiProperty({
    required: false,
    type: ClienteOrderByInput,
  })
  @Field(() => ClienteOrderByInput, { nullable: true })
  @Type(() => ClienteOrderByInput)
  orderBy?: ClienteOrderByInput;

  @ApiProperty({
    required: false,
    type: Number,
  })
  @Field(() => Number, { nullable: true })
  @Type(() => Number)
  skip?: number;

  @ApiProperty({
    required: false,
    type: Number,
  })
  @Field(() => Number, { nullable: true })
  @Type(() => Number)
  take?: number;
}

export { ClienteFindManyArgs };
