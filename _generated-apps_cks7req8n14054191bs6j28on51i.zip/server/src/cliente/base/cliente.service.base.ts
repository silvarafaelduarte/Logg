import { PrismaService } from "nestjs-prisma";
import { Prisma, Cliente, Entrega } from "@prisma/client";

export class ClienteServiceBase {
  constructor(protected readonly prisma: PrismaService) {}

  async count<T extends Prisma.ClienteFindManyArgs>(
    args: Prisma.SelectSubset<T, Prisma.ClienteFindManyArgs>
  ): Promise<number> {
    return this.prisma.cliente.count(args);
  }

  async findMany<T extends Prisma.ClienteFindManyArgs>(
    args: Prisma.SelectSubset<T, Prisma.ClienteFindManyArgs>
  ): Promise<Cliente[]> {
    return this.prisma.cliente.findMany(args);
  }
  async findOne<T extends Prisma.ClienteFindUniqueArgs>(
    args: Prisma.SelectSubset<T, Prisma.ClienteFindUniqueArgs>
  ): Promise<Cliente | null> {
    return this.prisma.cliente.findUnique(args);
  }
  async create<T extends Prisma.ClienteCreateArgs>(
    args: Prisma.SelectSubset<T, Prisma.ClienteCreateArgs>
  ): Promise<Cliente> {
    return this.prisma.cliente.create<T>(args);
  }
  async update<T extends Prisma.ClienteUpdateArgs>(
    args: Prisma.SelectSubset<T, Prisma.ClienteUpdateArgs>
  ): Promise<Cliente> {
    return this.prisma.cliente.update<T>(args);
  }
  async delete<T extends Prisma.ClienteDeleteArgs>(
    args: Prisma.SelectSubset<T, Prisma.ClienteDeleteArgs>
  ): Promise<Cliente> {
    return this.prisma.cliente.delete(args);
  }

  async findEntregas(
    parentId: string,
    args: Prisma.EntregaFindManyArgs
  ): Promise<Entrega[]> {
    return this.prisma.cliente
      .findUnique({
        where: { id: parentId },
      })
      .entregas(args);
  }
}
