import { ArgsType, Field } from "@nestjs/graphql";
import { ClienteWhereUniqueInput } from "./ClienteWhereUniqueInput";

@ArgsType()
class DeleteClienteArgs {
  @Field(() => ClienteWhereUniqueInput, { nullable: false })
  where!: ClienteWhereUniqueInput;
}

export { DeleteClienteArgs };
