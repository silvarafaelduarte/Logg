import * as common from "@nestjs/common";
import * as graphql from "@nestjs/graphql";
import * as apollo from "apollo-server-express";
import * as nestAccessControl from "nest-access-control";
import * as gqlDefaultAuthGuard from "../../auth/gqlDefaultAuth.guard";
import * as gqlACGuard from "../../auth/gqlAC.guard";
import * as gqlUserRoles from "../../auth/gqlUserRoles.decorator";
import * as abacUtil from "../../auth/abac.util";
import { isRecordNotFoundError } from "../../prisma.util";
import { MetaQueryPayload } from "../../util/MetaQueryPayload";
import { CreateClienteArgs } from "./CreateClienteArgs";
import { UpdateClienteArgs } from "./UpdateClienteArgs";
import { DeleteClienteArgs } from "./DeleteClienteArgs";
import { ClienteFindManyArgs } from "./ClienteFindManyArgs";
import { ClienteFindUniqueArgs } from "./ClienteFindUniqueArgs";
import { Cliente } from "./Cliente";
import { EntregaFindManyArgs } from "../../entrega/base/EntregaFindManyArgs";
import { Entrega } from "../../entrega/base/Entrega";
import { ClienteService } from "../cliente.service";

@graphql.Resolver(() => Cliente)
@common.UseGuards(
  gqlDefaultAuthGuard.GqlDefaultAuthGuard,
  gqlACGuard.GqlACGuard
)
export class ClienteResolverBase {
  constructor(
    protected readonly service: ClienteService,
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {}

  @graphql.Query(() => MetaQueryPayload)
  @nestAccessControl.UseRoles({
    resource: "Cliente",
    action: "read",
    possession: "any",
  })
  async _clientesMeta(
    @graphql.Args() args: ClienteFindManyArgs
  ): Promise<MetaQueryPayload> {
    const results = await this.service.count({
      ...args,
      skip: undefined,
      take: undefined,
    });
    return {
      count: results,
    };
  }

  @graphql.Query(() => [Cliente])
  @nestAccessControl.UseRoles({
    resource: "Cliente",
    action: "read",
    possession: "any",
  })
  async clientes(
    @graphql.Args() args: ClienteFindManyArgs,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Cliente[]> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "any",
      resource: "Cliente",
    });
    const results = await this.service.findMany(args);
    return results.map((result) => permission.filter(result));
  }

  @graphql.Query(() => Cliente, { nullable: true })
  @nestAccessControl.UseRoles({
    resource: "Cliente",
    action: "read",
    possession: "own",
  })
  async cliente(
    @graphql.Args() args: ClienteFindUniqueArgs,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Cliente | null> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "own",
      resource: "Cliente",
    });
    const result = await this.service.findOne(args);
    if (result === null) {
      return null;
    }
    return permission.filter(result);
  }

  @graphql.Mutation(() => Cliente)
  @nestAccessControl.UseRoles({
    resource: "Cliente",
    action: "create",
    possession: "any",
  })
  async createCliente(
    @graphql.Args() args: CreateClienteArgs,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Cliente> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "create",
      possession: "any",
      resource: "Cliente",
    });
    const invalidAttributes = abacUtil.getInvalidAttributes(
      permission,
      args.data
    );
    if (invalidAttributes.length) {
      const properties = invalidAttributes
        .map((attribute: string) => JSON.stringify(attribute))
        .join(", ");
      const roles = userRoles
        .map((role: string) => JSON.stringify(role))
        .join(",");
      throw new apollo.ApolloError(
        `providing the properties: ${properties} on ${"Cliente"} creation is forbidden for roles: ${roles}`
      );
    }
    // @ts-ignore
    return await this.service.create({
      ...args,
      data: args.data,
    });
  }

  @graphql.Mutation(() => Cliente)
  @nestAccessControl.UseRoles({
    resource: "Cliente",
    action: "update",
    possession: "any",
  })
  async updateCliente(
    @graphql.Args() args: UpdateClienteArgs,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Cliente | null> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "update",
      possession: "any",
      resource: "Cliente",
    });
    const invalidAttributes = abacUtil.getInvalidAttributes(
      permission,
      args.data
    );
    if (invalidAttributes.length) {
      const properties = invalidAttributes
        .map((attribute: string) => JSON.stringify(attribute))
        .join(", ");
      const roles = userRoles
        .map((role: string) => JSON.stringify(role))
        .join(",");
      throw new apollo.ApolloError(
        `providing the properties: ${properties} on ${"Cliente"} update is forbidden for roles: ${roles}`
      );
    }
    try {
      // @ts-ignore
      return await this.service.update({
        ...args,
        data: args.data,
      });
    } catch (error) {
      if (isRecordNotFoundError(error)) {
        throw new apollo.ApolloError(
          `No resource was found for ${JSON.stringify(args.where)}`
        );
      }
      throw error;
    }
  }

  @graphql.Mutation(() => Cliente)
  @nestAccessControl.UseRoles({
    resource: "Cliente",
    action: "delete",
    possession: "any",
  })
  async deleteCliente(
    @graphql.Args() args: DeleteClienteArgs
  ): Promise<Cliente | null> {
    try {
      // @ts-ignore
      return await this.service.delete(args);
    } catch (error) {
      if (isRecordNotFoundError(error)) {
        throw new apollo.ApolloError(
          `No resource was found for ${JSON.stringify(args.where)}`
        );
      }
      throw error;
    }
  }

  @graphql.ResolveField(() => [Entrega])
  @nestAccessControl.UseRoles({
    resource: "Cliente",
    action: "read",
    possession: "any",
  })
  async entregas(
    @graphql.Parent() parent: Cliente,
    @graphql.Args() args: EntregaFindManyArgs,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Entrega[]> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "any",
      resource: "Entrega",
    });
    const results = await this.service.findEntregas(parent.id, args);

    if (!results) {
      return [];
    }

    return results.map((result) => permission.filter(result));
  }
}
