import { ArgsType, Field } from "@nestjs/graphql";
import { ClienteCreateInput } from "./ClienteCreateInput";

@ArgsType()
class CreateClienteArgs {
  @Field(() => ClienteCreateInput, { nullable: false })
  data!: ClienteCreateInput;
}

export { CreateClienteArgs };
