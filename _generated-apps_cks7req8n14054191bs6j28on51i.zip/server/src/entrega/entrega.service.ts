import { Injectable } from "@nestjs/common";
import { PrismaService } from "nestjs-prisma";
import { EntregaServiceBase } from "./base/entrega.service.base";

@Injectable()
export class EntregaService extends EntregaServiceBase {
  constructor(protected readonly prisma: PrismaService) {
    super(prisma);
  }
}
