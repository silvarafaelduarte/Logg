import * as common from "@nestjs/common";
import * as swagger from "@nestjs/swagger";
import * as nestAccessControl from "nest-access-control";
import { EntregaService } from "./entrega.service";
import { EntregaControllerBase } from "./base/entrega.controller.base";

@swagger.ApiBasicAuth()
@swagger.ApiTags("entregas")
@common.Controller("entregas")
export class EntregaController extends EntregaControllerBase {
  constructor(
    protected readonly service: EntregaService,
    @nestAccessControl.InjectRolesBuilder()
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {
    super(service, rolesBuilder);
  }
}
