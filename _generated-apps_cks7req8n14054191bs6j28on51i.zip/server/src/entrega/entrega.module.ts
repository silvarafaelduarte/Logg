import { Module } from "@nestjs/common";
import { EntregaModuleBase } from "./base/entrega.module.base";
import { EntregaService } from "./entrega.service";
import { EntregaController } from "./entrega.controller";
import { EntregaResolver } from "./entrega.resolver";

@Module({
  imports: [EntregaModuleBase],
  controllers: [EntregaController],
  providers: [EntregaService, EntregaResolver],
  exports: [EntregaService],
})
export class EntregaModule {}
