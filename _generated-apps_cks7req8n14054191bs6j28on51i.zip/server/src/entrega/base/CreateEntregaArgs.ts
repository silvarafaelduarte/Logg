import { ArgsType, Field } from "@nestjs/graphql";
import { EntregaCreateInput } from "./EntregaCreateInput";

@ArgsType()
class CreateEntregaArgs {
  @Field(() => EntregaCreateInput, { nullable: false })
  data!: EntregaCreateInput;
}

export { CreateEntregaArgs };
