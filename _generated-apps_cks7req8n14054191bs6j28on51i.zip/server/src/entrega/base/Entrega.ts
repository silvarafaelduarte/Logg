import { ObjectType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import { Cliente } from "../../cliente/base/Cliente";
import {
  ValidateNested,
  IsDate,
  IsOptional,
  IsString,
  IsNumber,
} from "class-validator";
import { Type } from "class-transformer";
import { Destinatario } from "../../destinatario/base/Destinatario";
import { Ocorrencia } from "../../ocorrencia/base/Ocorrencia";
import { StatusEntrega } from "../../statusEntrega/base/StatusEntrega";
@ObjectType()
class Entrega {
  @ApiProperty({
    required: true,
    type: () => Cliente,
  })
  @ValidateNested()
  @Type(() => Cliente)
  cliente?: Cliente;

  @ApiProperty({
    required: true,
  })
  @IsDate()
  @Type(() => Date)
  @Field(() => Date)
  createdAt!: Date;

  @ApiProperty({
    required: false,
  })
  @IsDate()
  @Type(() => Date)
  @IsOptional()
  @Field(() => Date, {
    nullable: true,
  })
  dataFinalizada!: Date | null;

  @ApiProperty({
    required: true,
  })
  @IsDate()
  @Type(() => Date)
  @Field(() => Date)
  dataPedido!: Date;

  @ApiProperty({
    required: true,
    type: () => Destinatario,
  })
  @ValidateNested()
  @Type(() => Destinatario)
  destinatario?: Destinatario;

  @ApiProperty({
    required: true,
    type: String,
  })
  @IsString()
  @Field(() => String)
  id!: string;

  @ApiProperty({
    required: false,
    type: () => [Ocorrencia],
  })
  @ValidateNested()
  @Type(() => Ocorrencia)
  @IsOptional()
  ocorrencia?: Array<Ocorrencia>;

  @ApiProperty({
    required: false,
    type: () => StatusEntrega,
  })
  @ValidateNested()
  @Type(() => StatusEntrega)
  @IsOptional()
  statusEntrega?: StatusEntrega | null;

  @ApiProperty({
    required: true,
    type: Number,
  })
  @IsNumber()
  @Field(() => Number)
  taxa!: number;

  @ApiProperty({
    required: true,
  })
  @IsDate()
  @Type(() => Date)
  @Field(() => Date)
  updatedAt!: Date;
}
export { Entrega };
