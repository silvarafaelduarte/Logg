import { ArgsType, Field } from "@nestjs/graphql";
import { EntregaWhereUniqueInput } from "./EntregaWhereUniqueInput";

@ArgsType()
class EntregaFindUniqueArgs {
  @Field(() => EntregaWhereUniqueInput, { nullable: false })
  where!: EntregaWhereUniqueInput;
}

export { EntregaFindUniqueArgs };
