import { ArgsType, Field } from "@nestjs/graphql";
import { EntregaWhereUniqueInput } from "./EntregaWhereUniqueInput";

@ArgsType()
class DeleteEntregaArgs {
  @Field(() => EntregaWhereUniqueInput, { nullable: false })
  where!: EntregaWhereUniqueInput;
}

export { DeleteEntregaArgs };
