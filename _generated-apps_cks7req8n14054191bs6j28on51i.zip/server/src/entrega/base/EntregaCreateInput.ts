import { InputType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import { ClienteWhereUniqueInput } from "../../cliente/base/ClienteWhereUniqueInput";
import { ValidateNested, IsDate, IsOptional, IsNumber } from "class-validator";
import { Type } from "class-transformer";
import { DestinatarioWhereUniqueInput } from "../../destinatario/base/DestinatarioWhereUniqueInput";
import { StatusEntregaWhereUniqueInput } from "../../statusEntrega/base/StatusEntregaWhereUniqueInput";
@InputType()
class EntregaCreateInput {
  @ApiProperty({
    required: true,
    type: () => ClienteWhereUniqueInput,
  })
  @ValidateNested()
  @Type(() => ClienteWhereUniqueInput)
  @Field(() => ClienteWhereUniqueInput)
  cliente!: ClienteWhereUniqueInput;

  @ApiProperty({
    required: false,
  })
  @IsDate()
  @Type(() => Date)
  @IsOptional()
  @Field(() => Date, {
    nullable: true,
  })
  dataFinalizada?: Date | null;

  @ApiProperty({
    required: true,
  })
  @IsDate()
  @Type(() => Date)
  @Field(() => Date)
  dataPedido!: Date;

  @ApiProperty({
    required: true,
    type: () => DestinatarioWhereUniqueInput,
  })
  @ValidateNested()
  @Type(() => DestinatarioWhereUniqueInput)
  @Field(() => DestinatarioWhereUniqueInput)
  destinatario!: DestinatarioWhereUniqueInput;

  @ApiProperty({
    required: false,
    type: () => StatusEntregaWhereUniqueInput,
  })
  @ValidateNested()
  @Type(() => StatusEntregaWhereUniqueInput)
  @IsOptional()
  @Field(() => StatusEntregaWhereUniqueInput, {
    nullable: true,
  })
  statusEntrega?: StatusEntregaWhereUniqueInput | null;

  @ApiProperty({
    required: true,
    type: Number,
  })
  @IsNumber()
  @Field(() => Number)
  taxa!: number;
}
export { EntregaCreateInput };
