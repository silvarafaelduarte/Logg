import { ArgsType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import { EntregaWhereInput } from "./EntregaWhereInput";
import { Type } from "class-transformer";
import { EntregaOrderByInput } from "./EntregaOrderByInput";

@ArgsType()
class EntregaFindManyArgs {
  @ApiProperty({
    required: false,
    type: () => EntregaWhereInput,
  })
  @Field(() => EntregaWhereInput, { nullable: true })
  @Type(() => EntregaWhereInput)
  where?: EntregaWhereInput;

  @ApiProperty({
    required: false,
    type: EntregaOrderByInput,
  })
  @Field(() => EntregaOrderByInput, { nullable: true })
  @Type(() => EntregaOrderByInput)
  orderBy?: EntregaOrderByInput;

  @ApiProperty({
    required: false,
    type: Number,
  })
  @Field(() => Number, { nullable: true })
  @Type(() => Number)
  skip?: number;

  @ApiProperty({
    required: false,
    type: Number,
  })
  @Field(() => Number, { nullable: true })
  @Type(() => Number)
  take?: number;
}

export { EntregaFindManyArgs };
