import { PrismaService } from "nestjs-prisma";
import {
  Prisma,
  Entrega,
  Ocorrencia,
  Cliente,
  Destinatario,
  StatusEntrega,
} from "@prisma/client";

export class EntregaServiceBase {
  constructor(protected readonly prisma: PrismaService) {}

  async count<T extends Prisma.EntregaFindManyArgs>(
    args: Prisma.SelectSubset<T, Prisma.EntregaFindManyArgs>
  ): Promise<number> {
    return this.prisma.entrega.count(args);
  }

  async findMany<T extends Prisma.EntregaFindManyArgs>(
    args: Prisma.SelectSubset<T, Prisma.EntregaFindManyArgs>
  ): Promise<Entrega[]> {
    return this.prisma.entrega.findMany(args);
  }
  async findOne<T extends Prisma.EntregaFindUniqueArgs>(
    args: Prisma.SelectSubset<T, Prisma.EntregaFindUniqueArgs>
  ): Promise<Entrega | null> {
    return this.prisma.entrega.findUnique(args);
  }
  async create<T extends Prisma.EntregaCreateArgs>(
    args: Prisma.SelectSubset<T, Prisma.EntregaCreateArgs>
  ): Promise<Entrega> {
    return this.prisma.entrega.create<T>(args);
  }
  async update<T extends Prisma.EntregaUpdateArgs>(
    args: Prisma.SelectSubset<T, Prisma.EntregaUpdateArgs>
  ): Promise<Entrega> {
    return this.prisma.entrega.update<T>(args);
  }
  async delete<T extends Prisma.EntregaDeleteArgs>(
    args: Prisma.SelectSubset<T, Prisma.EntregaDeleteArgs>
  ): Promise<Entrega> {
    return this.prisma.entrega.delete(args);
  }

  async findOcorrencia(
    parentId: string,
    args: Prisma.OcorrenciaFindManyArgs
  ): Promise<Ocorrencia[]> {
    return this.prisma.entrega
      .findUnique({
        where: { id: parentId },
      })
      .ocorrencia(args);
  }

  async getCliente(parentId: string): Promise<Cliente | null> {
    return this.prisma.entrega
      .findUnique({
        where: { id: parentId },
      })
      .cliente();
  }

  async getDestinatario(parentId: string): Promise<Destinatario | null> {
    return this.prisma.entrega
      .findUnique({
        where: { id: parentId },
      })
      .destinatario();
  }

  async getStatusEntrega(parentId: string): Promise<StatusEntrega | null> {
    return this.prisma.entrega
      .findUnique({
        where: { id: parentId },
      })
      .statusEntrega();
  }
}
