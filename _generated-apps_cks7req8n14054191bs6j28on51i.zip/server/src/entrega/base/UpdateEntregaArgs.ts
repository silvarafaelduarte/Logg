import { ArgsType, Field } from "@nestjs/graphql";
import { EntregaWhereUniqueInput } from "./EntregaWhereUniqueInput";
import { EntregaUpdateInput } from "./EntregaUpdateInput";

@ArgsType()
class UpdateEntregaArgs {
  @Field(() => EntregaWhereUniqueInput, { nullable: false })
  where!: EntregaWhereUniqueInput;
  @Field(() => EntregaUpdateInput, { nullable: false })
  data!: EntregaUpdateInput;
}

export { UpdateEntregaArgs };
