import * as common from "@nestjs/common";
import * as swagger from "@nestjs/swagger";
import * as nestMorgan from "nest-morgan";
import * as nestAccessControl from "nest-access-control";
import * as defaultAuthGuard from "../../auth/defaultAuth.guard";
import * as abacUtil from "../../auth/abac.util";
import { isRecordNotFoundError } from "../../prisma.util";
import * as errors from "../../errors";
import { Request } from "express";
import { plainToClass } from "class-transformer";
import { EntregaService } from "../entrega.service";
import { EntregaCreateInput } from "./EntregaCreateInput";
import { EntregaWhereInput } from "./EntregaWhereInput";
import { EntregaWhereUniqueInput } from "./EntregaWhereUniqueInput";
import { EntregaFindManyArgs } from "./EntregaFindManyArgs";
import { EntregaUpdateInput } from "./EntregaUpdateInput";
import { Entrega } from "./Entrega";
import { OcorrenciaWhereInput } from "../../ocorrencia/base/OcorrenciaWhereInput";
import { Ocorrencia } from "../../ocorrencia/base/Ocorrencia";

export class EntregaControllerBase {
  constructor(
    protected readonly service: EntregaService,
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {}

  @common.UseInterceptors(nestMorgan.MorganInterceptor("combined"))
  @common.UseGuards(
    defaultAuthGuard.DefaultAuthGuard,
    nestAccessControl.ACGuard
  )
  @common.Post()
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "create",
    possession: "any",
  })
  @swagger.ApiCreatedResponse({ type: Entrega })
  @swagger.ApiForbiddenResponse({ type: errors.ForbiddenException })
  async create(
    @common.Body() data: EntregaCreateInput,
    @nestAccessControl.UserRoles() userRoles: string[]
  ): Promise<Entrega> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "create",
      possession: "any",
      resource: "Entrega",
    });
    const invalidAttributes = abacUtil.getInvalidAttributes(permission, data);
    if (invalidAttributes.length) {
      const properties = invalidAttributes
        .map((attribute: string) => JSON.stringify(attribute))
        .join(", ");
      const roles = userRoles
        .map((role: string) => JSON.stringify(role))
        .join(",");
      throw new errors.ForbiddenException(
        `providing the properties: ${properties} on ${"Entrega"} creation is forbidden for roles: ${roles}`
      );
    }
    return await this.service.create({
      data: {
        ...data,

        cliente: {
          connect: data.cliente,
        },

        destinatario: {
          connect: data.destinatario,
        },

        statusEntrega: data.statusEntrega
          ? {
              connect: data.statusEntrega,
            }
          : undefined,
      },
      select: {
        cliente: {
          select: {
            id: true,
          },
        },

        createdAt: true,
        dataFinalizada: true,
        dataPedido: true,

        destinatario: {
          select: {
            id: true,
          },
        },

        id: true,

        statusEntrega: {
          select: {
            id: true,
          },
        },

        taxa: true,
        updatedAt: true,
      },
    });
  }

  @common.UseInterceptors(nestMorgan.MorganInterceptor("combined"))
  @common.UseGuards(
    defaultAuthGuard.DefaultAuthGuard,
    nestAccessControl.ACGuard
  )
  @common.Get()
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "read",
    possession: "any",
  })
  @swagger.ApiOkResponse({ type: [Entrega] })
  @swagger.ApiForbiddenResponse()
  @swagger.ApiQuery({
    type: () => EntregaFindManyArgs,
    style: "deepObject",
    explode: true,
  })
  async findMany(
    @common.Req() request: Request,
    @nestAccessControl.UserRoles() userRoles: string[]
  ): Promise<Entrega[]> {
    const args = plainToClass(EntregaFindManyArgs, request.query);

    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "any",
      resource: "Entrega",
    });
    const results = await this.service.findMany({
      ...args,
      select: {
        cliente: {
          select: {
            id: true,
          },
        },

        createdAt: true,
        dataFinalizada: true,
        dataPedido: true,

        destinatario: {
          select: {
            id: true,
          },
        },

        id: true,

        statusEntrega: {
          select: {
            id: true,
          },
        },

        taxa: true,
        updatedAt: true,
      },
    });
    return results.map((result) => permission.filter(result));
  }

  @common.UseInterceptors(nestMorgan.MorganInterceptor("combined"))
  @common.UseGuards(
    defaultAuthGuard.DefaultAuthGuard,
    nestAccessControl.ACGuard
  )
  @common.Get("/:id")
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "read",
    possession: "own",
  })
  @swagger.ApiOkResponse({ type: Entrega })
  @swagger.ApiNotFoundResponse({ type: errors.NotFoundException })
  @swagger.ApiForbiddenResponse({ type: errors.ForbiddenException })
  async findOne(
    @common.Param() params: EntregaWhereUniqueInput,
    @nestAccessControl.UserRoles() userRoles: string[]
  ): Promise<Entrega | null> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "own",
      resource: "Entrega",
    });
    const result = await this.service.findOne({
      where: params,
      select: {
        cliente: {
          select: {
            id: true,
          },
        },

        createdAt: true,
        dataFinalizada: true,
        dataPedido: true,

        destinatario: {
          select: {
            id: true,
          },
        },

        id: true,

        statusEntrega: {
          select: {
            id: true,
          },
        },

        taxa: true,
        updatedAt: true,
      },
    });
    if (result === null) {
      throw new errors.NotFoundException(
        `No resource was found for ${JSON.stringify(params)}`
      );
    }
    return permission.filter(result);
  }

  @common.UseInterceptors(nestMorgan.MorganInterceptor("combined"))
  @common.UseGuards(
    defaultAuthGuard.DefaultAuthGuard,
    nestAccessControl.ACGuard
  )
  @common.Patch("/:id")
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "update",
    possession: "any",
  })
  @swagger.ApiOkResponse({ type: Entrega })
  @swagger.ApiNotFoundResponse({ type: errors.NotFoundException })
  @swagger.ApiForbiddenResponse({ type: errors.ForbiddenException })
  async update(
    @common.Param() params: EntregaWhereUniqueInput,
    @common.Body()
    data: EntregaUpdateInput,
    @nestAccessControl.UserRoles() userRoles: string[]
  ): Promise<Entrega | null> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "update",
      possession: "any",
      resource: "Entrega",
    });
    const invalidAttributes = abacUtil.getInvalidAttributes(permission, data);
    if (invalidAttributes.length) {
      const properties = invalidAttributes
        .map((attribute: string) => JSON.stringify(attribute))
        .join(", ");
      const roles = userRoles
        .map((role: string) => JSON.stringify(role))
        .join(",");
      throw new errors.ForbiddenException(
        `providing the properties: ${properties} on ${"Entrega"} update is forbidden for roles: ${roles}`
      );
    }
    try {
      return await this.service.update({
        where: params,
        data: {
          ...data,

          cliente: {
            connect: data.cliente,
          },

          destinatario: {
            connect: data.destinatario,
          },

          statusEntrega: data.statusEntrega
            ? {
                connect: data.statusEntrega,
              }
            : undefined,
        },
        select: {
          cliente: {
            select: {
              id: true,
            },
          },

          createdAt: true,
          dataFinalizada: true,
          dataPedido: true,

          destinatario: {
            select: {
              id: true,
            },
          },

          id: true,

          statusEntrega: {
            select: {
              id: true,
            },
          },

          taxa: true,
          updatedAt: true,
        },
      });
    } catch (error) {
      if (isRecordNotFoundError(error)) {
        throw new errors.NotFoundException(
          `No resource was found for ${JSON.stringify(params)}`
        );
      }
      throw error;
    }
  }

  @common.UseInterceptors(nestMorgan.MorganInterceptor("combined"))
  @common.UseGuards(
    defaultAuthGuard.DefaultAuthGuard,
    nestAccessControl.ACGuard
  )
  @common.Delete("/:id")
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "delete",
    possession: "any",
  })
  @swagger.ApiOkResponse({ type: Entrega })
  @swagger.ApiNotFoundResponse({ type: errors.NotFoundException })
  @swagger.ApiForbiddenResponse({ type: errors.ForbiddenException })
  async delete(
    @common.Param() params: EntregaWhereUniqueInput
  ): Promise<Entrega | null> {
    try {
      return await this.service.delete({
        where: params,
        select: {
          cliente: {
            select: {
              id: true,
            },
          },

          createdAt: true,
          dataFinalizada: true,
          dataPedido: true,

          destinatario: {
            select: {
              id: true,
            },
          },

          id: true,

          statusEntrega: {
            select: {
              id: true,
            },
          },

          taxa: true,
          updatedAt: true,
        },
      });
    } catch (error) {
      if (isRecordNotFoundError(error)) {
        throw new errors.NotFoundException(
          `No resource was found for ${JSON.stringify(params)}`
        );
      }
      throw error;
    }
  }

  @common.UseInterceptors(nestMorgan.MorganInterceptor("combined"))
  @common.UseGuards(
    defaultAuthGuard.DefaultAuthGuard,
    nestAccessControl.ACGuard
  )
  @common.Get("/:id/ocorrencia")
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "read",
    possession: "any",
  })
  @swagger.ApiQuery({
    type: () => OcorrenciaWhereInput,
    style: "deepObject",
    explode: true,
  })
  async findManyOcorrencia(
    @common.Req() request: Request,
    @common.Param() params: EntregaWhereUniqueInput,
    @nestAccessControl.UserRoles() userRoles: string[]
  ): Promise<Ocorrencia[]> {
    const query: OcorrenciaWhereInput = request.query;
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "any",
      resource: "Ocorrencia",
    });
    const results = await this.service.findOcorrencia(params.id, {
      where: query,
      select: {
        createdAt: true,
        dataRegistro: true,
        descricao: true,
        id: true,
        updatedAt: true,
      },
    });
    return results.map((result) => permission.filter(result));
  }

  @common.UseInterceptors(nestMorgan.MorganInterceptor("combined"))
  @common.UseGuards(
    defaultAuthGuard.DefaultAuthGuard,
    nestAccessControl.ACGuard
  )
  @common.Post("/:id/ocorrencia")
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "update",
    possession: "any",
  })
  async createOcorrencia(
    @common.Param() params: EntregaWhereUniqueInput,
    @common.Body() body: EntregaWhereUniqueInput[],
    @nestAccessControl.UserRoles() userRoles: string[]
  ): Promise<void> {
    const data = {
      ocorrencia: {
        connect: body,
      },
    };
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "update",
      possession: "any",
      resource: "Entrega",
    });
    const invalidAttributes = abacUtil.getInvalidAttributes(permission, data);
    if (invalidAttributes.length) {
      const roles = userRoles
        .map((role: string) => JSON.stringify(role))
        .join(",");
      throw new common.ForbiddenException(
        `Updating the relationship: ${
          invalidAttributes[0]
        } of ${"Entrega"} is forbidden for roles: ${roles}`
      );
    }
    await this.service.update({
      where: params,
      data,
      select: { id: true },
    });
  }

  @common.UseInterceptors(nestMorgan.MorganInterceptor("combined"))
  @common.UseGuards(
    defaultAuthGuard.DefaultAuthGuard,
    nestAccessControl.ACGuard
  )
  @common.Patch("/:id/ocorrencia")
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "update",
    possession: "any",
  })
  async updateOcorrencia(
    @common.Param() params: EntregaWhereUniqueInput,
    @common.Body() body: EntregaWhereUniqueInput[],
    @nestAccessControl.UserRoles() userRoles: string[]
  ): Promise<void> {
    const data = {
      ocorrencia: {
        set: body,
      },
    };
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "update",
      possession: "any",
      resource: "Entrega",
    });
    const invalidAttributes = abacUtil.getInvalidAttributes(permission, data);
    if (invalidAttributes.length) {
      const roles = userRoles
        .map((role: string) => JSON.stringify(role))
        .join(",");
      throw new common.ForbiddenException(
        `Updating the relationship: ${
          invalidAttributes[0]
        } of ${"Entrega"} is forbidden for roles: ${roles}`
      );
    }
    await this.service.update({
      where: params,
      data,
      select: { id: true },
    });
  }

  @common.UseInterceptors(nestMorgan.MorganInterceptor("combined"))
  @common.UseGuards(
    defaultAuthGuard.DefaultAuthGuard,
    nestAccessControl.ACGuard
  )
  @common.Delete("/:id/ocorrencia")
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "update",
    possession: "any",
  })
  async deleteOcorrencia(
    @common.Param() params: EntregaWhereUniqueInput,
    @common.Body() body: EntregaWhereUniqueInput[],
    @nestAccessControl.UserRoles() userRoles: string[]
  ): Promise<void> {
    const data = {
      ocorrencia: {
        disconnect: body,
      },
    };
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "update",
      possession: "any",
      resource: "Entrega",
    });
    const invalidAttributes = abacUtil.getInvalidAttributes(permission, data);
    if (invalidAttributes.length) {
      const roles = userRoles
        .map((role: string) => JSON.stringify(role))
        .join(",");
      throw new common.ForbiddenException(
        `Updating the relationship: ${
          invalidAttributes[0]
        } of ${"Entrega"} is forbidden for roles: ${roles}`
      );
    }
    await this.service.update({
      where: params,
      data,
      select: { id: true },
    });
  }
}
