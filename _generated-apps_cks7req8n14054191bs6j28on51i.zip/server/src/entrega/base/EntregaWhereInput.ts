import { InputType, Field } from "@nestjs/graphql";
import { ApiProperty } from "@nestjs/swagger";
import { ClienteWhereUniqueInput } from "../../cliente/base/ClienteWhereUniqueInput";
import { ValidateNested, IsOptional } from "class-validator";
import { Type } from "class-transformer";
import { DateTimeNullableFilter } from "../../util/DateTimeNullableFilter";
import { DateTimeFilter } from "../../util/DateTimeFilter";
import { DestinatarioWhereUniqueInput } from "../../destinatario/base/DestinatarioWhereUniqueInput";
import { StringFilter } from "../../util/StringFilter";
import { StatusEntregaWhereUniqueInput } from "../../statusEntrega/base/StatusEntregaWhereUniqueInput";
import { FloatFilter } from "../../util/FloatFilter";
@InputType()
class EntregaWhereInput {
  @ApiProperty({
    required: false,
    type: () => ClienteWhereUniqueInput,
  })
  @ValidateNested()
  @Type(() => ClienteWhereUniqueInput)
  @IsOptional()
  @Field(() => ClienteWhereUniqueInput, {
    nullable: true,
  })
  cliente?: ClienteWhereUniqueInput;

  @ApiProperty({
    required: false,
    type: DateTimeNullableFilter,
  })
  @Type(() => DateTimeNullableFilter)
  @IsOptional()
  @Field(() => DateTimeNullableFilter, {
    nullable: true,
  })
  dataFinalizada?: DateTimeNullableFilter;

  @ApiProperty({
    required: false,
    type: DateTimeFilter,
  })
  @Type(() => DateTimeFilter)
  @IsOptional()
  @Field(() => DateTimeFilter, {
    nullable: true,
  })
  dataPedido?: DateTimeFilter;

  @ApiProperty({
    required: false,
    type: () => DestinatarioWhereUniqueInput,
  })
  @ValidateNested()
  @Type(() => DestinatarioWhereUniqueInput)
  @IsOptional()
  @Field(() => DestinatarioWhereUniqueInput, {
    nullable: true,
  })
  destinatario?: DestinatarioWhereUniqueInput;

  @ApiProperty({
    required: false,
    type: StringFilter,
  })
  @Type(() => StringFilter)
  @IsOptional()
  @Field(() => StringFilter, {
    nullable: true,
  })
  id?: StringFilter;

  @ApiProperty({
    required: false,
    type: () => StatusEntregaWhereUniqueInput,
  })
  @ValidateNested()
  @Type(() => StatusEntregaWhereUniqueInput)
  @IsOptional()
  @Field(() => StatusEntregaWhereUniqueInput, {
    nullable: true,
  })
  statusEntrega?: StatusEntregaWhereUniqueInput;

  @ApiProperty({
    required: false,
    type: FloatFilter,
  })
  @Type(() => FloatFilter)
  @IsOptional()
  @Field(() => FloatFilter, {
    nullable: true,
  })
  taxa?: FloatFilter;
}
export { EntregaWhereInput };
