import * as common from "@nestjs/common";
import * as graphql from "@nestjs/graphql";
import * as apollo from "apollo-server-express";
import * as nestAccessControl from "nest-access-control";
import * as gqlDefaultAuthGuard from "../../auth/gqlDefaultAuth.guard";
import * as gqlACGuard from "../../auth/gqlAC.guard";
import * as gqlUserRoles from "../../auth/gqlUserRoles.decorator";
import * as abacUtil from "../../auth/abac.util";
import { isRecordNotFoundError } from "../../prisma.util";
import { MetaQueryPayload } from "../../util/MetaQueryPayload";
import { CreateEntregaArgs } from "./CreateEntregaArgs";
import { UpdateEntregaArgs } from "./UpdateEntregaArgs";
import { DeleteEntregaArgs } from "./DeleteEntregaArgs";
import { EntregaFindManyArgs } from "./EntregaFindManyArgs";
import { EntregaFindUniqueArgs } from "./EntregaFindUniqueArgs";
import { Entrega } from "./Entrega";
import { OcorrenciaFindManyArgs } from "../../ocorrencia/base/OcorrenciaFindManyArgs";
import { Ocorrencia } from "../../ocorrencia/base/Ocorrencia";
import { Cliente } from "../../cliente/base/Cliente";
import { Destinatario } from "../../destinatario/base/Destinatario";
import { StatusEntrega } from "../../statusEntrega/base/StatusEntrega";
import { EntregaService } from "../entrega.service";

@graphql.Resolver(() => Entrega)
@common.UseGuards(
  gqlDefaultAuthGuard.GqlDefaultAuthGuard,
  gqlACGuard.GqlACGuard
)
export class EntregaResolverBase {
  constructor(
    protected readonly service: EntregaService,
    protected readonly rolesBuilder: nestAccessControl.RolesBuilder
  ) {}

  @graphql.Query(() => MetaQueryPayload)
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "read",
    possession: "any",
  })
  async _entregasMeta(
    @graphql.Args() args: EntregaFindManyArgs
  ): Promise<MetaQueryPayload> {
    const results = await this.service.count({
      ...args,
      skip: undefined,
      take: undefined,
    });
    return {
      count: results,
    };
  }

  @graphql.Query(() => [Entrega])
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "read",
    possession: "any",
  })
  async entregas(
    @graphql.Args() args: EntregaFindManyArgs,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Entrega[]> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "any",
      resource: "Entrega",
    });
    const results = await this.service.findMany(args);
    return results.map((result) => permission.filter(result));
  }

  @graphql.Query(() => Entrega, { nullable: true })
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "read",
    possession: "own",
  })
  async entrega(
    @graphql.Args() args: EntregaFindUniqueArgs,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Entrega | null> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "own",
      resource: "Entrega",
    });
    const result = await this.service.findOne(args);
    if (result === null) {
      return null;
    }
    return permission.filter(result);
  }

  @graphql.Mutation(() => Entrega)
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "create",
    possession: "any",
  })
  async createEntrega(
    @graphql.Args() args: CreateEntregaArgs,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Entrega> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "create",
      possession: "any",
      resource: "Entrega",
    });
    const invalidAttributes = abacUtil.getInvalidAttributes(
      permission,
      args.data
    );
    if (invalidAttributes.length) {
      const properties = invalidAttributes
        .map((attribute: string) => JSON.stringify(attribute))
        .join(", ");
      const roles = userRoles
        .map((role: string) => JSON.stringify(role))
        .join(",");
      throw new apollo.ApolloError(
        `providing the properties: ${properties} on ${"Entrega"} creation is forbidden for roles: ${roles}`
      );
    }
    // @ts-ignore
    return await this.service.create({
      ...args,
      data: {
        ...args.data,

        cliente: {
          connect: args.data.cliente,
        },

        destinatario: {
          connect: args.data.destinatario,
        },

        statusEntrega: args.data.statusEntrega
          ? {
              connect: args.data.statusEntrega,
            }
          : undefined,
      },
    });
  }

  @graphql.Mutation(() => Entrega)
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "update",
    possession: "any",
  })
  async updateEntrega(
    @graphql.Args() args: UpdateEntregaArgs,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Entrega | null> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "update",
      possession: "any",
      resource: "Entrega",
    });
    const invalidAttributes = abacUtil.getInvalidAttributes(
      permission,
      args.data
    );
    if (invalidAttributes.length) {
      const properties = invalidAttributes
        .map((attribute: string) => JSON.stringify(attribute))
        .join(", ");
      const roles = userRoles
        .map((role: string) => JSON.stringify(role))
        .join(",");
      throw new apollo.ApolloError(
        `providing the properties: ${properties} on ${"Entrega"} update is forbidden for roles: ${roles}`
      );
    }
    try {
      // @ts-ignore
      return await this.service.update({
        ...args,
        data: {
          ...args.data,

          cliente: {
            connect: args.data.cliente,
          },

          destinatario: {
            connect: args.data.destinatario,
          },

          statusEntrega: args.data.statusEntrega
            ? {
                connect: args.data.statusEntrega,
              }
            : undefined,
        },
      });
    } catch (error) {
      if (isRecordNotFoundError(error)) {
        throw new apollo.ApolloError(
          `No resource was found for ${JSON.stringify(args.where)}`
        );
      }
      throw error;
    }
  }

  @graphql.Mutation(() => Entrega)
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "delete",
    possession: "any",
  })
  async deleteEntrega(
    @graphql.Args() args: DeleteEntregaArgs
  ): Promise<Entrega | null> {
    try {
      // @ts-ignore
      return await this.service.delete(args);
    } catch (error) {
      if (isRecordNotFoundError(error)) {
        throw new apollo.ApolloError(
          `No resource was found for ${JSON.stringify(args.where)}`
        );
      }
      throw error;
    }
  }

  @graphql.ResolveField(() => [Ocorrencia])
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "read",
    possession: "any",
  })
  async ocorrencia(
    @graphql.Parent() parent: Entrega,
    @graphql.Args() args: OcorrenciaFindManyArgs,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Ocorrencia[]> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "any",
      resource: "Ocorrencia",
    });
    const results = await this.service.findOcorrencia(parent.id, args);

    if (!results) {
      return [];
    }

    return results.map((result) => permission.filter(result));
  }

  @graphql.ResolveField(() => Cliente, { nullable: true })
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "read",
    possession: "any",
  })
  async cliente(
    @graphql.Parent() parent: Entrega,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Cliente | null> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "any",
      resource: "Cliente",
    });
    const result = await this.service.getCliente(parent.id);

    if (!result) {
      return null;
    }
    return permission.filter(result);
  }

  @graphql.ResolveField(() => Destinatario, { nullable: true })
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "read",
    possession: "any",
  })
  async destinatario(
    @graphql.Parent() parent: Entrega,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<Destinatario | null> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "any",
      resource: "Destinatario",
    });
    const result = await this.service.getDestinatario(parent.id);

    if (!result) {
      return null;
    }
    return permission.filter(result);
  }

  @graphql.ResolveField(() => StatusEntrega, { nullable: true })
  @nestAccessControl.UseRoles({
    resource: "Entrega",
    action: "read",
    possession: "any",
  })
  async statusEntrega(
    @graphql.Parent() parent: Entrega,
    @gqlUserRoles.UserRoles() userRoles: string[]
  ): Promise<StatusEntrega | null> {
    const permission = this.rolesBuilder.permission({
      role: userRoles,
      action: "read",
      possession: "any",
      resource: "StatusEntrega",
    });
    const result = await this.service.getStatusEntrega(parent.id);

    if (!result) {
      return null;
    }
    return permission.filter(result);
  }
}
