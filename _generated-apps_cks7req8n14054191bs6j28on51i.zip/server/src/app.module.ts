import { Module } from "@nestjs/common";
import { UserModule } from "./user/user.module";
import { DestinatarioModule } from "./destinatario/destinatario.module";
import { EntregaModule } from "./entrega/entrega.module";
import { OcorrenciaModule } from "./ocorrencia/ocorrencia.module";
import { ClienteModule } from "./cliente/cliente.module";
import { StatusEntregaModule } from "./statusEntrega/statusEntrega.module";
import { ACLModule } from "./auth/acl.module";
import { AuthModule } from "./auth/auth.module";
import { MorganModule } from "nest-morgan";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { ServeStaticModule } from "@nestjs/serve-static";
import { ServeStaticOptionsService } from "./serveStaticOptions.service";
import { GraphQLModule } from "@nestjs/graphql";

@Module({
  controllers: [],
  imports: [
    UserModule,
    DestinatarioModule,
    EntregaModule,
    OcorrenciaModule,
    ClienteModule,
    StatusEntregaModule,
    ACLModule,
    AuthModule,
    MorganModule,
    ConfigModule.forRoot({ isGlobal: true }),
    ServeStaticModule.forRootAsync({
      useClass: ServeStaticOptionsService,
    }),
    GraphQLModule.forRootAsync({
      useFactory: (configService) => {
        const playground = configService.get("GRAPHQL_PLAYGROUND");
        const introspection = configService.get("GRAPHQL_INTROSPECTION");
        return {
          autoSchemaFile: true,
          playground,
          introspection: playground || introspection,
        };
      },
      inject: [ConfigService],
      imports: [ConfigModule],
    }),
  ],
  providers: [],
})
export class AppModule {}
